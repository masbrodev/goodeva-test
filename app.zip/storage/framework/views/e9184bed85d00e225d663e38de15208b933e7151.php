<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css"> 
</head>
<body>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Data Kategori</h3>
</div>
</div>
</div>

<script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
<script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>    
<?php echo Toastr::message(); ?>

</body>
</html><?php /**PATH D:\project\Laravel\7.24\resources\views/pages/produk.blade.php ENDPATH**/ ?>