

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Toastr', true); ?>
<div class="container">
    <div class="col-md-12">
        <div class="card card-success card-outline">
            <div class="card-header">
                <h4 class="card-title">Data Surat Keluar</h4>
                <a class="btn btn-outline-primary float-right" href="<?php echo e(URL::to('suratkeluar/create')); ?>">Tambah</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover display" id="surat-keluar">
                        <thead>
                            <tr>
                                <th style="width: 10px">#</th>
                                <th>NA.</th>
                                <th>Tujuan Surat</th>
                                <th>Perihal</th>
                                <th>Nomor Surat</th>
                                <th>Tanggal</th>
                                <th class="notexport">Info</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr onClick="window.location.href='<?php echo e(URL::to('suratkeluar/'.$r->id)); ?>'">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($r->nomor_agenda); ?></td>
                                <td><?php echo e($r->tujuan_surat); ?></td>
                                <td><?php echo e($r->perihal); ?></td>
                                <td><?php echo e($r->nomor_surat); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($r->tanggal_keluar)->isoFormat('D-MMMM-Y')); ?></td>
                                <td>
                                    <div class="input-group">
                                        <?php if(count($r->berkas2) == 0): ?>
                                        <i class="fa fa-file" aria-hidden="true" style="color:red;"></i>&nbsp;
                                        <?php else: ?>
                                        <span class="badge badge-success"><?php echo e(count($r->berkas2)); ?></span>&nbsp;
                                        <?php endif; ?>
                                        <?php if($r->tindak_lanjut == 'Belum Tuntas'): ?>
                                        <i class="fa fa-window-close" aria-hidden="true" style="color:red;"></i>
                                        <?php elseif($r->tindak_lanjut == 'Tuntas'): ?>
                                        <i class="fa fa-check-square" aria-hidden="true" style="color:green;"></i>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
</div>
<!-- /.card -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
<?php echo Toastr::message(); ?>

<script>
    $(function() {
        $("#surat-keluar").DataTable({
            language: {
                search: 'Cari:',
                previous: 'Cari:',
                lengthMenu: 'Tampilkan _MENU_ baris',
                zeroRecords: 'Data Tidak Ditemukan',
                info: 'Total data _MAX_',
                infoEmpty: 'Data Kosong',
                infoFiltered: '(filtered from _MAX_ total records)'
            },
            "responsive": true,
            "autoWidth": false,
            dom: 'Bfrtip',
            buttons: [{
                extend: 'excel',
                text: 'Export',
                exportOptions: {
                    columns: ':not(.notexport)'
                }
            }]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Kemendes\Manajemen Surat\resources\views/pages/dataSK.blade.php ENDPATH**/ ?>